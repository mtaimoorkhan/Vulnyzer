---
title: News
layout:  null
tab: true
order: 2
tags: csrfguard
---

# Latest News

We are working on a new version of CSRFGuard including a lot of merge request with good proposals and new code to fix known issues on XSS attacks that bypass CSRFGuard.

## Target date for the new release 4.0 : 2021

We need your help. If you want to give few hours of your time please reach out to us.
