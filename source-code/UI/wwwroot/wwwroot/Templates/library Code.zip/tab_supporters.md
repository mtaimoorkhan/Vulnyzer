---

title: Supporters
displaytext: Our Supporters
layout: null
tab: true
order: 4
tags: csrfguard

---

## Supporters

CSRFGuard is developed by a worldwide of volunteers in Morocco, France, India, China, Singapore, Indonesia, Canada and more.

## Special Thanks

Thanks to Trent Schmidt and Joel Orlina (JIRA) for there help.
