 public class XMLInjection {
     string XMLString="<";
     int int1 = 10 ;
    public void doSomething(int c) {
         string NonXMLString="v2";
         int int2 = 15 ;
                                   }
                           } 