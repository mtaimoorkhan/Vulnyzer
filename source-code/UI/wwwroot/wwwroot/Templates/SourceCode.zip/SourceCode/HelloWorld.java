// HelloWorld.java
class HelloWorld {
  int test() {
    String s = null;
    return s.length();
  }
}