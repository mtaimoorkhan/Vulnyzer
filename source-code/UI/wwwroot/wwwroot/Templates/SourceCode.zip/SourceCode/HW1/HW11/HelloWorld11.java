// HelloWorld11.java
class HelloWorld11 {
  int test() {
    String s = null;
    return s.length();
  }
}