// HelloWorld1.java
class HelloWorld1 {
  int test() {
    String s = null;
    return s.length();
  }
}