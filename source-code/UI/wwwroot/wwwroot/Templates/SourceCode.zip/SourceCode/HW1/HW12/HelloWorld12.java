// HelloWorld12.java
class HelloWorld12 {
  int test() {
    String s = null;
    return s.length();
  }
}